# Energy Forecasting — Experimental Results

- Experiment run: `c876fda70a14`

- Dataset: `energy_dataset.csv` (SHA256 `14cd13e020d87af0ab49db8e0f1e4d308320ec5b8d2dec23bab4d27c75c7733a`)

- Hardware: [PhysicalDevice(name='/physical_device:GPU:0', device_type='GPU')]

- Epochs per model: 100; batch size: 64; recurrent units: 32

- Data split: chronological 70% train / 15% validation / 15% test; train-only scaler

- Metrics: MAE, MSE, RMSE, R², computed on held-out test data in original price units (EUR/MWh; MSE squared)



## Stacked recurrent models: five typologies per family

### RNN

| typology | MAE | MSE | RMSE | R2 | parameters |
| --- | --- | --- | --- | --- | --- |
| many_to_one | 1.5200 | 4.3343 | 2.0819 | 0.9308 | 3329.0000 |
| many_to_many_synced | 1.8877 | 6.0439 | 2.4584 | 0.9035 | 3329.0000 |
| one_to_one | 2.1286 | 8.3684 | 2.8928 | 0.8660 | 3329.0000 |
| many_to_many_seq2seq | 3.4536 | 19.5835 | 4.4253 | 0.6876 | 5409.0000 |
| one_to_many | 5.3367 | 49.7112 | 7.0506 | 0.2049 | 5409.0000 |

**Lowest-RMSE typology:** `many_to_one` (RMSE 2.0819). **Highest-R² typology:** `many_to_one` (R² 0.9308).



### LSTM

| typology | MAE | MSE | RMSE | R2 | parameters |
| --- | --- | --- | --- | --- | --- |
| many_to_one | 1.5585 | 4.4213 | 2.1027 | 0.9294 | 13217.0000 |
| many_to_many_synced | 1.6112 | 4.7765 | 2.1855 | 0.9238 | 13217.0000 |
| one_to_one | 2.0278 | 8.0564 | 2.8384 | 0.8710 | 13217.0000 |
| many_to_many_seq2seq | 3.2323 | 18.0725 | 4.2512 | 0.7117 | 21537.0000 |
| one_to_many | 6.2753 | 59.9712 | 7.7441 | 0.0408 | 21537.0000 |

**Lowest-RMSE typology:** `many_to_one` (RMSE 2.1027). **Highest-R² typology:** `many_to_one` (R² 0.9294).



### GRU

| typology | MAE | MSE | RMSE | R2 | parameters |
| --- | --- | --- | --- | --- | --- |
| many_to_one | 1.5267 | 4.2160 | 2.0533 | 0.9327 | 10113.0000 |
| many_to_many_synced | 1.6321 | 4.8465 | 2.2015 | 0.9227 | 10113.0000 |
| one_to_one | 2.0549 | 8.0935 | 2.8449 | 0.8704 | 10113.0000 |
| many_to_many_seq2seq | 3.6996 | 23.5400 | 4.8518 | 0.6245 | 16449.0000 |
| one_to_many | 6.3144 | 60.4158 | 7.7728 | 0.0337 | 16449.0000 |

**Lowest-RMSE typology:** `many_to_one` (RMSE 2.0533). **Highest-R² typology:** `many_to_one` (R² 0.9327).



## Lowest-RMSE recurrent family for each matched typology

| typology | family | MAE | MSE | RMSE | R2 |
| --- | --- | --- | --- | --- | --- |
| many_to_many_seq2seq | LSTM | 3.2323 | 18.0725 | 4.2512 | 0.7117 |
| many_to_many_synced | LSTM | 1.6112 | 4.7765 | 2.1855 | 0.9238 |
| many_to_one | GRU | 1.5267 | 4.2160 | 2.0533 | 0.9327 |
| one_to_many | RNN | 5.3367 | 49.7112 | 7.0506 | 0.2049 |
| one_to_one | LSTM | 2.0278 | 8.0564 | 2.8384 | 0.8710 |

These within-typology comparisons use the same data and target structure. Different typologies predict different output horizons/alignments, so their scores should not be used to claim that one architecture is universally superior.



## CNN–RNN with 32 filters, kernel size 3, 100 epochs: comparison to original RNN

| typology | baseline_MAE | CNN_MAE | baseline_MSE | CNN_MSE | baseline_RMSE | CNN_RMSE | baseline_R2 | CNN_R2 | RMSE_change_pct | CNN_improves_RMSE |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| one_to_one | 2.0140 | 2.0225 | 7.9997 | 8.0060 | 2.8284 | 2.8295 | 0.8719 | 0.8718 | 0.0396 | False |
| many_to_one | 1.5590 | 1.5334 | 4.6478 | 4.3645 | 2.1559 | 2.0891 | 0.9258 | 0.9303 | -3.0960 | True |
| one_to_many | 5.6087 | 6.0053 | 54.1231 | 57.4078 | 7.3568 | 7.5768 | 0.1344 | 0.0818 | 2.9897 | False |
| many_to_many_synced | 1.8096 | 1.6536 | 5.7520 | 5.0356 | 2.3983 | 2.2440 | 0.9082 | 0.9196 | -6.4342 | True |
| many_to_many_seq2seq | 3.4684 | 3.6678 | 20.8115 | 22.4721 | 4.5620 | 4.7405 | 0.6680 | 0.6415 | 3.9129 | False |

**Observed result:** CNN–RNN has a lower held-out-test RMSE than the matched original RNN for **2 of 5 typologies**. This is an association in this run, not proof of a general advantage.

- **One-to-One:** RMSE increased (worsened) by 0.04% (RNN 2.8284; CNN–RNN 2.8295).

- **Many-to-One:** RMSE decreased (improved) by 3.10% (RNN 2.1559; CNN–RNN 2.0891).

- **One-to-Many:** RMSE increased (worsened) by 2.99% (RNN 7.3568; CNN–RNN 7.5768).

- **Many-to-Many (Synced):** RMSE decreased (improved) by 6.43% (RNN 2.3983; CNN–RNN 2.2440).

- **Many-to-Many (Seq2Seq):** RMSE increased (worsened) by 3.91% (RNN 4.5620; CNN–RNN 4.7405).



## Conclusion and interpretation

On this test partition, the CNN feature extractor improved RMSE for 2/5 matched RNN comparisons. Whether extra convolution helps depends on the input sequence and model, and it can worsen generalization by adding complexity or overfitting. For one-timestep inputs, the 3-wide kernel is padded and does not have three real timesteps to extract temporal patterns from. The stacked RNN/LSTM/GRU results indicate which of the five tested typologies had the lowest measured RMSE within each family (tables above), but different horizons must be considered when interpreting this ranking.



## Limitations

- These are results from one data split and one random seed; repeat seeds to estimate variability.

- Overlapping many-to-many forecast positions are flattened for the overall metrics, and therefore do not represent independent observations.

- Original One-to-Many and Seq2Seq RNN baselines contain an encoder and decoder; "one-layer RNN" is shorthand for the source baseline, not literally one layer in those two cases.

- Running 100 epochs as required may overfit; inspect train/validation curves, and avoid selecting on the test set.

- The preprocessing matches the exercise notebooks, including interpolation of missing hourly values.

- Test scores are in original price units; the MSE is in squared units.